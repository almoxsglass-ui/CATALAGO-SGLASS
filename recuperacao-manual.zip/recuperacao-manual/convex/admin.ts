import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";

export async function requireAdmin(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw new ConvexError({ code: "UNAUTHENTICATED", message: "Faça login." });
  }
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user || user.role !== "admin") {
    throw new ConvexError({ code: "FORBIDDEN", message: "Apenas administradores." });
  }
  return user;
}

export const isAdmin = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return false;
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    return user?.role === "admin";
  },
});

const productFields = {
  code: v.string(),
  name: v.string(),
  description: v.string(),
  brand: v.string(),
  category: v.string(),
  imageUrl: v.string(),
};

export const saveProduct = mutation({
  args: { id: v.optional(v.id("products")), ...productFields },
  handler: async (ctx, { id, ...fields }) => {
    await requireAdmin(ctx);
    const code = fields.code.trim();
    if (!code || !fields.name.trim()) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Código e nome são obrigatórios." });
    }
    const clash = await ctx.db
      .query("products")
      .withIndex("by_code", (q) => q.eq("code", code))
      .first();
    if (clash && clash._id !== id) {
      throw new ConvexError({ code: "CONFLICT", message: "Já existe uma peça com esse código." });
    }
    const data = { ...fields, code, name: fields.name.trim() };
    if (id) {
      await ctx.db.patch("products", id, data);
      return id;
    }
    return await ctx.db.insert("products", data);
  },
});

export const deleteProduct = mutation({
  args: { id: v.id("products") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    await ctx.db.delete("products", args.id);
    return null;
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

export const getStorageUrl = mutation({
  args: { storageId: v.id("_storage") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    return await ctx.storage.getUrl(args.storageId);
  },
});

export const saveCategory = mutation({
  args: { id: v.optional(v.id("categories")), name: v.string(), color: v.string() },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    const name = args.name.trim();
    if (!name) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Informe o nome." });
    }
    const clash = await ctx.db
      .query("categories")
      .withIndex("by_name", (q) => q.eq("name", name))
      .first();
    if (clash && clash._id !== args.id) {
      throw new ConvexError({ code: "CONFLICT", message: "Categoria já existe." });
    }
    if (args.id) {
      const old = await ctx.db.get("categories", args.id);
      await ctx.db.patch("categories", args.id, { name, color: args.color });
      // Products reference categories by name, so keep them in sync on rename (bounded batch)
      if (old && old.name !== name) {
        const items = await ctx.db
          .query("products")
          .withIndex("by_category_and_name", (q) => q.eq("category", old.name))
          .take(500);
        for (const p of items) await ctx.db.patch("products", p._id, { category: name });
      }
      return args.id;
    }
    return await ctx.db.insert("categories", { name, color: args.color });
  },
});

export const deleteCategory = mutation({
  args: { id: v.id("categories") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    const cat = await ctx.db.get("categories", args.id);
    if (!cat) return null;
    const used = await ctx.db
      .query("products")
      .withIndex("by_category_and_name", (q) => q.eq("category", cat.name))
      .first();
    if (used) {
      throw new ConvexError({
        code: "CONFLICT",
        message: "Há peças nesta categoria. Mova-as antes de excluir.",
      });
    }
    await ctx.db.delete("categories", args.id);
    return null;
  },
});

export const importProducts = mutation({
  args: { rows: v.array(v.object(productFields)) },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    if (args.rows.length > 200) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Máximo de 200 linhas por envio." });
    }
    let created = 0;
    let updated = 0;
    for (const row of args.rows) {
      const code = row.code.trim();
      const existing = await ctx.db
        .query("products")
        .withIndex("by_code", (q) => q.eq("code", code))
        .first();
      if (existing) {
        await ctx.db.patch("products", existing._id, { ...row, code });
        updated++;
      } else {
        await ctx.db.insert("products", { ...row, code });
        created++;
      }
      const cat = await ctx.db
        .query("categories")
        .withIndex("by_name", (q) => q.eq("name", row.category))
        .first();
      if (!cat && row.category) {
        await ctx.db.insert("categories", { name: row.category, color: "#8a8a8a" });
      }
    }
    return { created, updated };
  },
});
