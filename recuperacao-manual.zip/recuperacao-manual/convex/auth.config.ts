import { AuthConfig } from "convex/server";

export default {
  providers: [{
    domain: process.env.OIDC_ISSUER_URL!,
    applicationID: process.env.OIDC_APPLICATION_ID!,
  }],
} satisfies AuthConfig;
