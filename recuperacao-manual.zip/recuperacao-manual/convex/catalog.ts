import { paginationOptsValidator } from "convex/server";
import { v } from "convex/values";
import { query } from "./_generated/server";

export const listProducts = query({
  args: {
    paginationOpts: paginationOptsValidator,
    search: v.optional(v.string()),
    category: v.optional(v.string()),
    brand: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { search, category, brand } = args;
    if (search && search.trim().length > 0) {
      const term = search.trim();
      // Part codes are numeric: match them by prefix before falling back to text search
      if (/^\d+$/.test(term)) {
        return await ctx.db
          .query("products")
          .withIndex("by_code", (q) => q.gte("code", term).lt("code", term + "\uffff"))
          .paginate(args.paginationOpts);
      }
      return await ctx.db
        .query("products")
        .withSearchIndex("search_name", (q) => {
          const base = q.search("name", term);
          if (category && brand) return base.eq("category", category).eq("brand", brand);
          if (category) return base.eq("category", category);
          if (brand) return base.eq("brand", brand);
          return base;
        })
        .paginate(args.paginationOpts);
    }
    if (category) {
      return await ctx.db
        .query("products")
        .withIndex("by_category_and_name", (q) => q.eq("category", category))
        .paginate(args.paginationOpts);
    }
    if (brand) {
      return await ctx.db
        .query("products")
        .withIndex("by_brand_and_name", (q) => q.eq("brand", brand))
        .paginate(args.paginationOpts);
    }
    return await ctx.db
      .query("products")
      .withIndex("by_name")
      .paginate(args.paginationOpts);
  },
});

export const getProduct = query({
  args: { id: v.id("products") },
  handler: async (ctx, args) => {
    return await ctx.db.get("products", args.id);
  },
});

export const listCategories = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("categories").withIndex("by_name").take(200);
  },
});

export const listBrands = query({
  args: {},
  handler: async (ctx) => {
    // Small catalog (few hundred rows): derive brands from the products
    const products = await ctx.db.query("products").take(1000);
    return Array.from(new Set(products.map((p) => p.brand).filter(Boolean))).sort(
      (a, b) => a.localeCompare(b, "pt-BR"),
    );
  },
});

export const getProductByCode = query({
  args: { code: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("products")
      .withIndex("by_code", (q) => q.eq("code", args.code))
      .first();
  },
});
