import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { requireAdmin } from "./admin";

const hotspotValidator = v.object({
  n: v.number(),
  pt: v.string(),
  en: v.string(),
  code: v.string(),
  x: v.number(),
  y: v.number(),
});

const MAX_HOTSPOTS = 60;

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("diagrams").withIndex("by_order").take(50);
  },
});

export const save = mutation({
  args: {
    id: v.optional(v.id("diagrams")),
    title: v.string(),
    imageUrl: v.string(),
    hotspots: v.array(hotspotValidator),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    const title = args.title.trim();
    if (!title || !args.imageUrl.trim()) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Informe o título e a imagem." });
    }
    if (args.hotspots.length > MAX_HOTSPOTS) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Pontos demais no desenho." });
    }
    const hotspots = args.hotspots.map((h) => ({
      ...h,
      pt: h.pt.trim(),
      en: h.en.trim(),
      code: h.code.trim(),
      x: Math.min(100, Math.max(0, h.x)),
      y: Math.min(100, Math.max(0, h.y)),
    }));
    if (args.id) {
      await ctx.db.patch("diagrams", args.id, { title, imageUrl: args.imageUrl.trim(), hotspots });
      return args.id;
    }
    const last = await ctx.db.query("diagrams").withIndex("by_order").order("desc").first();
    return await ctx.db.insert("diagrams", {
      slug: `d-${Date.now()}`,
      title,
      imageUrl: args.imageUrl.trim(),
      order: (last?.order ?? 0) + 1,
      hotspots,
    });
  },
});

export const remove = mutation({
  args: { id: v.id("diagrams") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    await ctx.db.delete("diagrams", args.id);
    return null;
  },
});
