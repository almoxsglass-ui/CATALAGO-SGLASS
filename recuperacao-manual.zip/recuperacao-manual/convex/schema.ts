import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  products: defineTable({
    code: v.string(),
    name: v.string(),
    description: v.string(),
    brand: v.string(),
    category: v.string(),
    imageUrl: v.string(),
  })
    .index("by_code", ["code"])
    .index("by_name", ["name"])
    .index("by_brand_and_name", ["brand", "name"])
    .index("by_category_and_name", ["category", "name"])
    .searchIndex("search_name", {
      searchField: "name",
      filterFields: ["category", "brand"],
    }),

  categories: defineTable({
    name: v.string(),
    color: v.string(),
  }).index("by_name", ["name"]),
  users: defineTable({
    tokenIdentifier: v.string(),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    role: v.optional(v.union(v.literal("admin"), v.literal("user"))),
  })
    .index("by_token", ["tokenIdentifier"])
    .index("by_role", ["role"]),

  // Single-row table with the company contact settings
  settings: defineTable({
    whatsappNumber: v.string(),
    quoteEmail: v.string(),
    senderEmail: v.optional(v.string()),
  }),

  // Exploded-view drawings; hotspot x/y are percentages over the image
  diagrams: defineTable({
    slug: v.string(),
    title: v.string(),
    imageUrl: v.string(),
    order: v.number(),
    hotspots: v.array(
      v.object({
        n: v.number(),
        pt: v.string(),
        en: v.string(),
        code: v.string(),
        x: v.number(),
        y: v.number(),
      }),
    ),
  }).index("by_order", ["order"]),
});
