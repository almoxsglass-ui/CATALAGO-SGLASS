import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";

async function requireAdmin(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw new ConvexError({ code: "UNAUTHENTICATED", message: "Faça login." });
  }
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user || user.role !== "admin") {
    throw new ConvexError({ code: "FORBIDDEN", message: "Apenas administradores." });
  }
}

// Public: visitors only need to know the WhatsApp number and whether e-mail is available
export const getPublic = query({
  args: {},
  handler: async (ctx) => {
    const s = await ctx.db.query("settings").first();
    return {
      whatsappNumber: s?.whatsappNumber ?? "",
      quoteEmail: s?.quoteEmail ?? "",
    };
  },
});

export const getForAdmin = query({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    const s = await ctx.db.query("settings").first();
    return {
      whatsappNumber: s?.whatsappNumber ?? "",
      quoteEmail: s?.quoteEmail ?? "",
    };
  },
});

export const save = mutation({
  args: {
    whatsappNumber: v.string(),
    quoteEmail: v.string(),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);
    // wa.me needs digits only, with country code
    const digits = args.whatsappNumber.replace(/\D/g, "");
    const data = {
      whatsappNumber: digits && !digits.startsWith("55") ? `55${digits}` : digits,
      quoteEmail: args.quoteEmail.trim(),
    };
    const existing = await ctx.db.query("settings").first();
    if (existing) {
      await ctx.db.patch("settings", existing._id, data);
    } else {
      await ctx.db.insert("settings", data);
    }
    return null;
  },
});
