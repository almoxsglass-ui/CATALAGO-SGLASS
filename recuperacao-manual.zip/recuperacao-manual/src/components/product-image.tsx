import { useState } from "react";
import { ImageOffIcon } from "lucide-react";
import { cn } from "@/lib/utils.ts";

type ProductImageProps = {
  src: string;
  alt: string;
  className?: string;
};

// Photos come from external hosts that sometimes fail: show a neutral placeholder instead of a broken icon
export default function ProductImage({ src, alt, className }: ProductImageProps) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div className={cn("flex items-center justify-center bg-muted text-muted-foreground", className)}>
        <ImageOffIcon className="size-8" />
      </div>
    );
  }
  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={cn("bg-muted object-contain", className)}
    />
  );
}
