import { AuthProvider as OidcAuthProvider } from "react-oidc-context";

const authority = import.meta.env.VITE_OIDC_AUTHORITY;
const clientId = import.meta.env.VITE_OIDC_CLIENT_ID;

export function AuthProvider({ children }: { children: React.ReactNode }) {

  return (
    <OidcAuthProvider
      authority={authority || "http://localhost:9999"}
      client_id={clientId || "sglass-local-unconfigured"}
      redirect_uri={import.meta.env.VITE_OIDC_REDIRECT_URI || window.location.origin + "/auth/callback"}
      post_logout_redirect_uri={window.location.origin}
      response_type="code"
      scope={import.meta.env.VITE_OIDC_SCOPE || "openid profile email"}
      automaticSilentRenew
    >
      {children}
    </OidcAuthProvider>
  );
}
