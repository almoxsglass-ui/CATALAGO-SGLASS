import { ConvexProviderWithAuth, ConvexReactClient } from "convex/react";
import { useConvexOidcAuth } from "@/hooks/use-auth.ts";

const convexUrl = import.meta.env.VITE_CONVEX_URL ?? "http://localhost:3000";
const convex = new ConvexReactClient(convexUrl);

export function ConvexProvider({ children }: { children: React.ReactNode }) {
  return (
    <ConvexProviderWithAuth client={convex} useAuth={useConvexOidcAuth}>
      {children}
    </ConvexProviderWithAuth>
  );
}
