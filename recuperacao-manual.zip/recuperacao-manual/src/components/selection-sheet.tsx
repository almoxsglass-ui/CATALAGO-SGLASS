import { ClipboardListIcon, CopyIcon, FileDownIcon, MailIcon, MinusIcon, PlusIcon, Trash2Icon } from "lucide-react";
import { toast } from "sonner";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet.tsx";
import { Button } from "@/components/ui/button.tsx";
import ProductImage from "@/components/product-image.tsx";
import { downloadQuotePdf } from "@/lib/quote-pdf.ts";
import {
  buildMessage,
  mailtoUrl,
  clearSelection,
  removeItem,
  setQty,
  useSelection,
  whatsappUrl,
} from "@/lib/selection.ts";

export default function SelectionSheet() {
  const items = useSelection();
  const settings = useQuery(api.settings.getPublic, {});
  const total = items.reduce((n, i) => n + i.qty, 0);

  const copy = async () => {
    await navigator.clipboard.writeText(buildMessage(items));
    toast.success("Lista copiada");
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button size="sm" className="relative">
          <ClipboardListIcon /> Orçamento
          {total > 0 && (
            <span className="ml-1 rounded-full bg-primary-foreground px-1.5 text-xs font-bold text-primary">
              {total}
            </span>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="flex w-full flex-col gap-0 sm:max-w-md">
        <SheetHeader>
          <SheetTitle>Itens selecionados</SheetTitle>
          <SheetDescription>Monte sua lista e peça um orçamento.</SheetDescription>
        </SheetHeader>
        <div className="flex-1 space-y-3 overflow-y-auto px-4">
          {items.length === 0 && (
            <p className="py-10 text-center text-sm text-muted-foreground">
              Nenhum item ainda. Use "Adicionar ao orçamento" nas peças.
            </p>
          )}
          {items.map((i) => (
            <div key={i.id} className="flex gap-3 rounded-lg border p-2">
              <ProductImage src={i.imageUrl} alt={i.name} className="size-16 shrink-0 rounded" />
              <div className="min-w-0 flex-1 space-y-1">
                <p className="line-clamp-2 text-sm font-semibold">{i.name}</p>
                <p className="font-mono text-xs text-primary">{i.code}</p>
                <div className="flex items-center gap-1">
                  <Button size="icon" variant="secondary" className="size-7" onClick={() => setQty(i.id, i.qty - 1)}>
                    <MinusIcon />
                  </Button>
                  <span className="w-8 text-center text-sm">{i.qty}</span>
                  <Button size="icon" variant="secondary" className="size-7" onClick={() => setQty(i.id, i.qty + 1)}>
                    <PlusIcon />
                  </Button>
                  <Button size="icon" variant="ghost" className="ml-auto size-7" onClick={() => removeItem(i.id)}>
                    <Trash2Icon />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
        {items.length > 0 && (
          <div className="space-y-2 border-t p-4">
            {settings?.whatsappNumber ? (
              <Button asChild className="w-full">
                <a href={whatsappUrl(items, settings.whatsappNumber)} target="_blank" rel="noreferrer">
                  Pedir orçamento no WhatsApp
                </a>
              </Button>
            ) : (
              <Button
                className="w-full"
                onClick={() => toast.info("O WhatsApp ainda não foi configurado.")}
              >
                Pedir orçamento no WhatsApp
              </Button>
            )}
            {settings?.quoteEmail ? (
              <Button asChild variant="secondary" className="w-full">
                <a href={mailtoUrl(items, settings.quoteEmail)}>
                  <MailIcon /> Pedir orçamento por e-mail
                </a>
              </Button>
            ) : (
              <Button
                variant="secondary"
                className="w-full"
                onClick={() => toast.info("O e-mail ainda não foi configurado.")}
              >
                <MailIcon /> Pedir orçamento por e-mail
              </Button>
            )}
            <Button variant="secondary" className="w-full" onClick={async () => {
                toast.info("Gerando PDF...");
                await downloadQuotePdf(items);
              }}>
              <FileDownIcon /> Baixar PDF
            </Button>
            <div className="flex gap-2">
              <Button variant="secondary" className="flex-1" onClick={copy}>
                <CopyIcon /> Copiar lista
              </Button>
              <Button variant="ghost" onClick={clearSelection}>
                Limpar
              </Button>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
