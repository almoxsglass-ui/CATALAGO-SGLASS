import { Link } from "react-router-dom";
import { ShieldCheckIcon } from "lucide-react";

export default function SiteFooter() {
  return (
    <footer className="border-t bg-sidebar text-sidebar-foreground/70">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-6 text-sm">
        <p>
          Tecnologia que transforma. © {new Date().getFullYear()} SGLASS. Peças e componentes para equipamentos de
          processamento de vidro.
        </p>
        <Link
          to="/admin"
          className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-sidebar-foreground/20 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground transition hover:border-primary hover:bg-primary hover:text-primary-foreground"
        >
          <ShieldCheckIcon className="size-4" />
          Área administrativa
        </Link>
      </div>
    </footer>
  );
}
