import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { BookOpenIcon, Rotate3dIcon } from "lucide-react";
import ThemeToggle from "@/components/theme-toggle.tsx";
import SelectionSheet from "@/components/selection-sheet.tsx";

export default function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-sidebar-border bg-sidebar text-sidebar-foreground">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4">
        <Link to="/" className="flex shrink-0 items-center gap-3">
          <div className="relative h-9 w-[8.5rem] overflow-hidden sm:h-11 sm:w-40">
            <img
              src="/icons/sglass-logo-lockup.png"
              alt="SGLASS - Tecnologia que transforma"
              fetchPriority="high"
              decoding="async"
              className="absolute -left-[3.45rem] -top-[3.05rem] w-[14.4rem] max-w-none sm:-left-[4.3rem] sm:-top-[3.8rem] sm:w-72"
            />
          </div>
          <span className="hidden h-6 w-px bg-sidebar-foreground/20 sm:block" />
          <p className="hidden items-center gap-1.5 rounded-md border border-sidebar-foreground/15 bg-sidebar-accent/60 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-widest text-sidebar-foreground/80 transition hover:border-chart-2 hover:text-sidebar-foreground sm:flex">
            <BookOpenIcon className="size-3.5 text-chart-2" />
            Catálogo de peças
          </p>
        </Link>
        <nav className="min-w-0 flex-1 sm:ml-4">
          <Link
            to="/vistas-explodidas"
            aria-label="Vistas explodidas"
            className="group inline-flex cursor-pointer items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1.5 text-sm font-semibold text-primary transition hover:bg-primary hover:text-primary-foreground sm:px-3"
          >
            <motion.span
              animate={{ rotateY: 360 }}
              transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
              className="flex"
            >
              <Rotate3dIcon className="size-4" />
            </motion.span>
            <span className="hidden sm:inline">Vistas explodidas</span>
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <SelectionSheet />
        </div>
      </div>
      <Link
        to="/"
        className="flex cursor-pointer items-center justify-center gap-1.5 border-t border-sidebar-foreground/10 bg-sidebar-accent/60 py-1 text-[11px] font-semibold uppercase tracking-widest text-sidebar-foreground/80 transition active:bg-sidebar-accent sm:hidden"
      >
        <BookOpenIcon className="size-3.5 text-chart-2" />
        Catálogo de peças
      </Link>
      <div className="h-0.5 bg-chart-2" />
    </header>
  );
}
