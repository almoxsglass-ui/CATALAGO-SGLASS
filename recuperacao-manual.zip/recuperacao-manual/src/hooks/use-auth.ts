import { useCallback, useMemo } from "react";
import { useAuth as useOidcAuth } from "react-oidc-context";

export function useAuth() {
  const auth = useOidcAuth();
  const signin = useCallback(() => auth.signinRedirect(), [auth.signinRedirect]);
  const signout = useCallback(() => auth.signoutRedirect(), [auth.signoutRedirect]);
  return useMemo(() => ({
    isAuthenticated: auth.isAuthenticated,
    isLoading: auth.isLoading,
    error: auth.error,
    signin,
    signout,
  }), [auth.isAuthenticated, auth.isLoading, auth.error, signin, signout]);
}

export function useUser() {
  return useOidcAuth().user?.profile ?? null;
}

export function useConvexOidcAuth() {
  const auth = useOidcAuth();
  const fetchAccessToken = useCallback(async ({ forceRefreshToken }: { forceRefreshToken: boolean }) => {
    let user = auth.user;
    if (forceRefreshToken) {
      try { user = await auth.signinSilent(); } catch { return null; }
    }
    return user?.id_token ?? null;
  }, [auth.user, auth.signinSilent]);
  return useMemo(() => ({
    isLoading: auth.isLoading,
    isAuthenticated: Boolean(auth.isAuthenticated && auth.user?.id_token),
    fetchAccessToken,
  }), [auth.isLoading, auth.isAuthenticated, auth.user?.id_token, fetchAccessToken]);
}
