import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import type { SelectedItem } from "@/lib/selection.ts";

const BLUE: [number, number, number] = [30, 80, 200];
const GREEN: [number, number, number] = [90, 170, 40];

const IMG_SIZE = 16;

// Loads a photo as JPEG data via canvas; returns null when the host blocks it (CORS) or fails
function loadPhoto(url: string): Promise<string | null> {
  return new Promise((resolve) => {
    if (!url) return resolve(null);
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.referrerPolicy = "no-referrer";
    img.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = 160;
        canvas.height = 160;
        const ctx = canvas.getContext("2d");
        if (!ctx) return resolve(null);
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, 160, 160);
        const scale = Math.min(160 / img.width, 160 / img.height);
        const w = img.width * scale;
        const h = img.height * scale;
        ctx.drawImage(img, (160 - w) / 2, (160 - h) / 2, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.8));
      } catch {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = url;
  });
}

// Builds a quote PDF entirely in the browser and downloads it
export async function downloadQuotePdf(items: SelectedItem[]) {
  const photos = await Promise.all(items.map((i) => loadPhoto(i.imageUrl)));
  const doc = new jsPDF();
  const width = doc.internal.pageSize.getWidth();

  doc.setFillColor(15, 18, 30);
  doc.rect(0, 0, width, 28, "F");
  doc.setFillColor(...GREEN);
  doc.rect(0, 28, width, 1.5, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text("SGLASS", 14, 18);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.text("Tecnologia que transforma", width - 14, 18, { align: "right" });

  doc.setTextColor(30, 30, 30);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.text("Solicitação de orçamento", 14, 42);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text(`Data: ${new Date().toLocaleDateString("pt-BR")}`, 14, 49);

  const totalQty = items.reduce((n, i) => n + i.qty, 0);
  autoTable(doc, {
    startY: 55,
    head: [["Foto", "Qtd", "Código", "Peça", "Marca"]],
    body: items.map((i) => ["", String(i.qty), i.code, i.name, i.brand]),
    foot: [["", String(totalQty), "", `${items.length} item(ns) no total`, ""]],
    theme: "grid",
    headStyles: { fillColor: BLUE, textColor: 255 },
    footStyles: { fillColor: [235, 235, 235], textColor: 30, fontStyle: "bold" },
    columnStyles: {
      0: { cellWidth: IMG_SIZE + 4 },
      1: { halign: "center", cellWidth: 14 },
      2: { cellWidth: 30 },
    },
    styles: { fontSize: 9, valign: "middle", minCellHeight: IMG_SIZE + 4 },
    didDrawCell: (data) => {
      if (data.section !== "body" || data.column.index !== 0) return;
      const photo = photos[data.row.index];
      if (photo) doc.addImage(photo, "JPEG", data.cell.x + 2, data.cell.y + 2, IMG_SIZE, IMG_SIZE);
    },
  });

  doc.save(`orcamento-sglass-${new Date().toISOString().slice(0, 10)}.pdf`);
}
