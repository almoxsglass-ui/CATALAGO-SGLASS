import { useSyncExternalStore } from "react";

export type SelectedItem = {
  id: string;
  code: string;
  name: string;
  brand: string;
  imageUrl: string;
  qty: number;
};

// The WhatsApp number is configured by the admin in the panel (settings table)
const KEY = "sglass-selection";
const listeners = new Set<() => void>();
let cache: SelectedItem[] | null = null;

function read(): SelectedItem[] {
  if (cache) return cache;
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(KEY) ?? "[]");
    cache = Array.isArray(parsed) ? (parsed as SelectedItem[]) : [];
  } catch {
    cache = [];
  }
  return cache;
}

function write(items: SelectedItem[]) {
  cache = items;
  localStorage.setItem(KEY, JSON.stringify(items));
  listeners.forEach((l) => l());
}

export function addItem(item: Omit<SelectedItem, "qty">) {
  const items = read();
  const found = items.find((i) => i.id === item.id);
  write(found ? items.map((i) => (i.id === item.id ? { ...i, qty: i.qty + 1 } : i)) : [...items, { ...item, qty: 1 }]);
}

export function setQty(id: string, qty: number) {
  write(qty <= 0 ? read().filter((i) => i.id !== id) : read().map((i) => (i.id === id ? { ...i, qty } : i)));
}

export function removeItem(id: string) {
  write(read().filter((i) => i.id !== id));
}

export function clearSelection() {
  write([]);
}

export function useSelection(): SelectedItem[] {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    read,
  );
}

export function buildMessage(items: SelectedItem[]): string {
  const lines = items.map((i) => `- ${i.qty}x ${i.code} - ${i.name} (${i.brand})`);
  return `Olá! Gostaria de um orçamento para os itens:\n\n${lines.join("\n")}`;
}

export function whatsappUrl(items: SelectedItem[], number: string): string {
  return `https://wa.me/${number}?text=${encodeURIComponent(buildMessage(items))}`;
}

export function mailtoUrl(items: SelectedItem[], email: string): string {
  return `mailto:${email}?subject=${encodeURIComponent("Pedido de orçamento")}&body=${encodeURIComponent(buildMessage(items))}`;
}
