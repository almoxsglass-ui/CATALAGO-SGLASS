import { useMemo, useState } from "react";
import { usePaginatedQuery, useQuery } from "convex/react";
import { SearchXIcon } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { useDebounce } from "@/hooks/use-debounce.ts";
import SiteHeader from "@/components/site-header.tsx";
import SiteFooter from "@/components/site-footer.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import CatalogFilters, { ALL } from "./_components/catalog-filters.tsx";
import ProductCard from "./_components/product-card.tsx";

// Smaller first page on phones so the first paint is faster
const PAGE_SIZE =
  typeof window !== "undefined" && window.innerWidth < 640 ? 12 : 24;

export default function Index() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState(ALL);
  const [brand, setBrand] = useState(ALL);
  const [debouncedSearch] = useDebounce(search, 300);

  const categories = useQuery(api.catalog.listCategories, {});
  const brands = useQuery(api.catalog.listBrands, {});
  const { results, status, loadMore } = usePaginatedQuery(
    api.catalog.listProducts,
    {
      search: debouncedSearch.trim() || undefined,
      category: category === ALL ? undefined : category,
      brand: brand === ALL ? undefined : brand,
    },
    { initialNumItems: PAGE_SIZE },
  );

  const colorByCategory = useMemo(
    () => new Map((categories ?? []).map((c) => [c.name, c.color])),
    [categories],
  );

  return (
    <div className="flex min-h-screen flex-col overflow-x-hidden">
      <SiteHeader />
      <main className="mx-auto w-full max-w-7xl flex-1 space-y-4 px-3 py-4 sm:space-y-6 sm:px-4 sm:py-8">
        <img
          src="/icons/sglass-logo-lockup.png"
          alt="SGLASS - Tecnologia que transforma"
          decoding="async"
          className="h-28 w-full rounded-lg object-cover sm:h-56 md:h-72"
        />
        <CatalogFilters
          search={search}
          onSearchChange={setSearch}
          category={category}
          onCategoryChange={setCategory}
          brand={brand}
          onBrandChange={setBrand}
          categories={(categories ?? []).map((c) => c.name)}
          brands={brands ?? []}
        />

        {status === "LoadingFirstPage" ? (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="aspect-[3/4] w-full" />
            ))}
          </div>
        ) : results.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <SearchXIcon />
              </EmptyMedia>
              <EmptyTitle>Nenhuma peça encontrada</EmptyTitle>
              <EmptyDescription>
                Tente outro nome, código ou remova os filtros.
              </EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
            {results.map((p) => (
              <ProductCard
                key={p._id}
                product={p}
                color={colorByCategory.get(p.category)}
              />
            ))}
          </div>
        )}

        {(status === "CanLoadMore" || status === "LoadingMore") && (
          <div className="flex justify-center">
            <Button
              onClick={() => loadMore(PAGE_SIZE)}
              disabled={status === "LoadingMore"}
            >
              {status === "LoadingMore" ? "Carregando..." : "Ver mais peças"}
            </Button>
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
