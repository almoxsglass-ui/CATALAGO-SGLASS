import { SearchIcon, XIcon } from "lucide-react";
import { Input } from "@/components/ui/input.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";

export const ALL = "all";

type CatalogFiltersProps = {
  search: string;
  onSearchChange: (value: string) => void;
  category: string;
  onCategoryChange: (value: string) => void;
  brand: string;
  onBrandChange: (value: string) => void;
  categories: string[];
  brands: string[];
};

export default function CatalogFilters(props: CatalogFiltersProps) {
  const hasFilters = props.search || props.category !== ALL || props.brand !== ALL;

  const clear = () => {
    props.onSearchChange("");
    props.onCategoryChange(ALL);
    props.onBrandChange(ALL);
  };

  return (
    <div className="grid gap-3 rounded-lg border bg-card p-3 md:grid-cols-[1fr_220px_180px_auto]">
      <div className="relative">
        <SearchIcon className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={props.search}
          onChange={(e) => props.onSearchChange(e.target.value)}
          placeholder="Buscar por nome ou código"
          className="pl-9"
        />
      </div>
      <Select value={props.category} onValueChange={props.onCategoryChange}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Categoria" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={ALL}>Todas as categorias</SelectItem>
          {props.categories.map((c) => (
            <SelectItem key={c} value={c}>
              {c}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Select value={props.brand} onValueChange={props.onBrandChange}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Marca" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={ALL}>Todas as marcas</SelectItem>
          {props.brands.map((b) => (
            <SelectItem key={b} value={b}>
              {b}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Button variant="ghost" onClick={clear} disabled={!hasFilters}>
        <XIcon /> Limpar
      </Button>
    </div>
  );
}
