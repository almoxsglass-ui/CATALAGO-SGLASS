import { Link } from "react-router-dom";
import { PlusIcon } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button.tsx";
import { addItem } from "@/lib/selection.ts";
import ProductImage from "@/components/product-image.tsx";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";

type ProductCardProps = {
  product: Doc<"products">;
  color?: string;
};

export default function ProductCard({ product, color }: ProductCardProps) {
  return (
    <div className="group relative flex">
    <Link
      to={`/produto/${product._id}`}
      className="flex w-full cursor-pointer flex-col overflow-hidden rounded-lg border bg-card transition hover:-translate-y-0.5 hover:border-primary hover:shadow-md"
    >
      <ProductImage
        src={product.imageUrl}
        alt={product.name}
        className="aspect-square w-full p-3"
      />
      <div className="flex flex-1 flex-col gap-2 border-t p-3">
        <div className="flex items-center gap-2">
          <span
            className="size-2 shrink-0 rounded-full bg-muted-foreground"
            style={color ? { backgroundColor: color } : undefined}
          />
          <span className="truncate text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            {product.category}
          </span>
        </div>
        <h3 className="line-clamp-3 text-sm font-semibold leading-snug">
          {product.name}
        </h3>
        <div className="mt-auto flex items-center justify-between gap-2 pt-1">
          <span className="font-mono text-xs font-semibold text-primary">
            {product.code}
          </span>
          <span className="truncate rounded-sm bg-secondary px-1.5 py-0.5 text-[10px] font-semibold uppercase text-secondary-foreground">
            {product.brand}
          </span>
        </div>
      </div>
    </Link>
    <Button
      size="icon"
      className="absolute right-2 top-2 size-8"
      aria-label="Adicionar ao orçamento"
      onClick={() => {
        addItem({
          id: product._id,
          code: product.code,
          name: product.name,
          brand: product.brand,
          imageUrl: product.imageUrl,
        });
        toast.success("Adicionado ao orçamento");
      }}
    >
      <PlusIcon />
    </Button>
    </div>
  );
}
