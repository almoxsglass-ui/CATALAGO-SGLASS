import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import { PlusIcon, Trash2Icon } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { errorMessage } from "../_lib/errors.ts";

function CategoryRow({ cat }: { cat: Doc<"categories"> }) {
  const [name, setName] = useState(cat.name);
  const [color, setColor] = useState(cat.color);
  const save = useMutation(api.admin.saveCategory);
  const remove = useMutation(api.admin.deleteCategory);
  const dirty = name !== cat.name || color !== cat.color;

  const run = async (fn: () => Promise<unknown>, ok: string) => {
    try { await fn(); toast.success(ok); }
    catch (e) { toast.error(errorMessage(e)); }
  };

  return (
    <li className="flex items-center gap-2 p-2">
      <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="size-9 cursor-pointer rounded border bg-transparent" aria-label="Cor" />
      <Input value={name} onChange={(e) => setName(e.target.value)} />
      <Button size="sm" disabled={!dirty} onClick={() => run(() => save({ id: cat._id, name, color }), "Categoria salva")}>Salvar</Button>
      <Button size="icon" variant="ghost" aria-label="Excluir" onClick={() => run(() => remove({ id: cat._id }), "Categoria excluída")}><Trash2Icon /></Button>
    </li>
  );
}

export default function CategoriesTab() {
  const categories = useQuery(api.catalog.listCategories, {});
  const save = useMutation(api.admin.saveCategory);
  const [name, setName] = useState("");

  const add = async () => {
    try { await save({ name, color: "#8a8a8a" }); setName(""); }
    catch (e) { toast.error(errorMessage(e)); }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nova categoria" />
        <Button onClick={add} disabled={!name.trim()}><PlusIcon /> Adicionar</Button>
      </div>
      {categories === undefined ? <Skeleton className="h-64 w-full" /> : (
        <ul className="divide-y rounded-lg border bg-card">
          {categories.map((c) => <CategoryRow key={c._id} cat={c} />)}
        </ul>
      )}
    </div>
  );
}
