import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import { PlusIcon, Trash2Icon, UploadIcon } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";
import { errorMessage } from "../_lib/errors.ts";

type Hotspot = Doc<"diagrams">["hotspots"][number];
type Draft = { id?: Id<"diagrams">; title: string; imageUrl: string; hotspots: Hotspot[] };

const EMPTY: Draft = { title: "", imageUrl: "", hotspots: [] };
const round = (n: number) => Math.round(n * 10) / 10;

function Editor({ initial, onDone }: { initial: Draft; onDone: () => void }) {
  const [draft, setDraft] = useState(initial);
  const [selected, setSelected] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const save = useMutation(api.diagrams.save);
  const remove = useMutation(api.diagrams.remove);
  const getUploadUrl = useMutation(api.admin.generateUploadUrl);
  const getUrl = useMutation(api.admin.getStorageUrl);

  const updateSpot = (i: number, patch: Partial<Hotspot>) =>
    setDraft((d) => ({ ...d, hotspots: d.hotspots.map((h, k) => (k === i ? { ...h, ...patch } : h)) }));

  const placeSpot = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = round(((e.clientX - rect.left) / rect.width) * 100);
    const y = round(((e.clientY - rect.top) / rect.height) * 100);
    // With a point selected, a click moves it; otherwise a click adds a new one
    if (selected !== null) {
      updateSpot(selected, { x, y });
      return;
    }
    const n = draft.hotspots.reduce((m, h) => Math.max(m, h.n), 0) + 1;
    setDraft((d) => ({ ...d, hotspots: [...d.hotspots, { n, pt: "", en: "", code: "", x, y }] }));
    setSelected(draft.hotspots.length);
  };

  const upload = async (file: File) => {
    setBusy(true);
    try {
      const url = await getUploadUrl({});
      const res = await fetch(url, { method: "POST", headers: { "Content-Type": file.type }, body: file });
      const { storageId } = (await res.json()) as { storageId: Id<"_storage"> };
      const publicUrl = await getUrl({ storageId });
      if (publicUrl) setDraft((d) => ({ ...d, imageUrl: publicUrl }));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const submit = async () => {
    setBusy(true);
    try {
      await save({ id: draft.id, title: draft.title, imageUrl: draft.imageUrl, hotspots: draft.hotspots });
      toast.success("Vista explodida salva");
      onDone();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const del = async () => {
    if (!draft.id || !window.confirm("Excluir esta vista explodida?")) return;
    try {
      await remove({ id: draft.id });
      onDone();
    } catch (e) {
      toast.error(errorMessage(e));
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1"><Label>Título</Label><Input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} /></div>
        <div className="space-y-1">
          <Label>Imagem do desenho</Label>
          <div className="flex gap-2">
            <Input value={draft.imageUrl} onChange={(e) => setDraft({ ...draft, imageUrl: e.target.value })} placeholder="Endereço da imagem" />
            <Button asChild variant="secondary" disabled={busy}>
              <label className="cursor-pointer">
                <UploadIcon /> Enviar
                <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
              </label>
            </Button>
          </div>
        </div>
      </div>

      {draft.imageUrl && (
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground">
            {selected === null ? "Clique no desenho para adicionar um ponto numerado." : `Ponto ${draft.hotspots[selected]?.n} selecionado: clique no desenho para mover. Clique no ponto para soltar.`}
          </p>
          <div className="relative cursor-crosshair overflow-hidden rounded-lg border bg-white" onClick={placeSpot}>
            <img src={draft.imageUrl} alt="" className="block w-full select-none" draggable={false} />
            {draft.hotspots.map((h, i) => (
              <button key={h.n} type="button" style={{ left: `${h.x}%`, top: `${h.y}%` }} onClick={(e) => { e.stopPropagation(); setSelected(selected === i ? null : i); }}
                className={cn("absolute flex size-7 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-2 border-white bg-primary text-xs font-bold text-primary-foreground shadow", selected === i && "scale-125 ring-4 ring-primary/40")}>
                {h.n}
              </button>
            ))}
          </div>
        </div>
      )}

      <ul className="space-y-2">
        {draft.hotspots.map((h, i) => (
          <li key={h.n} className={cn("grid gap-2 rounded-lg border p-2 sm:grid-cols-[2.5rem_1fr_1fr_8rem_auto]", selected === i && "border-primary")}>
            <button type="button" onClick={() => setSelected(selected === i ? null : i)} className="flex size-9 cursor-pointer items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">{h.n}</button>
            <Input placeholder="Nome em português" value={h.pt} onChange={(e) => updateSpot(i, { pt: e.target.value })} />
            <Input placeholder="Nome em inglês" value={h.en} onChange={(e) => updateSpot(i, { en: e.target.value })} />
            <Input placeholder="Código" value={h.code} onChange={(e) => updateSpot(i, { code: e.target.value })} />
            <Button variant="ghost" size="icon" aria-label="Remover ponto" onClick={() => { setSelected(null); setDraft((d) => ({ ...d, hotspots: d.hotspots.filter((_, k) => k !== i) })); }}><Trash2Icon /></Button>
          </li>
        ))}
      </ul>

      <div className="flex flex-wrap gap-2">
        <Button onClick={submit} disabled={busy}>Salvar</Button>
        <Button variant="ghost" onClick={onDone}>Cancelar</Button>
        {draft.id && <Button variant="ghost" className="ml-auto text-destructive" onClick={del}><Trash2Icon /> Excluir</Button>}
      </div>
    </div>
  );
}

export default function DiagramsTab() {
  const diagrams = useQuery(api.diagrams.list, {});
  const [editing, setEditing] = useState<Draft | null>(null);

  if (diagrams === undefined) return <Skeleton className="h-64 w-full" />;
  if (editing) return <Editor key={editing.id ?? "new"} initial={editing} onDone={() => setEditing(null)} />;
  return (
    <div className="space-y-3">
      <Button onClick={() => setEditing(EMPTY)}><PlusIcon /> Nova vista explodida</Button>
      <ul className="space-y-2">
        {diagrams.map((d) => (
          <li key={d._id} className="flex items-center gap-3 rounded-lg border bg-card p-2">
            <img src={d.imageUrl} alt="" className="size-14 rounded bg-white object-contain" />
            <div className="min-w-0 flex-1"><p className="font-semibold">{d.title}</p><p className="text-xs text-muted-foreground">{d.hotspots.length} pontos</p></div>
            <Button variant="secondary" onClick={() => setEditing({ id: d._id, title: d.title, imageUrl: d.imageUrl, hotspots: d.hotspots })}>Editar</Button>
          </li>
        ))}
      </ul>
    </div>
  );
}
