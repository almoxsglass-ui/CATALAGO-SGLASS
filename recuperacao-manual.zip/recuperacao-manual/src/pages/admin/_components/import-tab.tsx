import { useState } from "react";
import Papa from "papaparse";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { FileSpreadsheetIcon } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { errorMessage } from "../_lib/errors.ts";

type Row = {
  code: string;
  name: string;
  description: string;
  brand: string;
  category: string;
  imageUrl: string;
};

const HEADERS: Record<string, keyof Row> = {
  codigo: "code", code: "code", nome: "name", name: "name",
  descricao: "description", description: "description",
  marca: "brand", brand: "brand", categoria: "category", category: "category",
  foto: "imageUrl", imagem: "imageUrl", imageurl: "imageUrl",
};

const BATCH = 100;

// Accents and case in column titles should not matter
const normalize = (h: string) =>
  h.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[\s_-]/g, "").toLowerCase();

export default function ImportTab() {
  const [rows, setRows] = useState<Row[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const importRows = useMutation(api.admin.importProducts);

  const onFile = (file: File) => {
    Papa.parse<Record<string, string>>(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: normalize,
      complete: (res) => {
        const problems = res.errors.map((e) => `Linha ${(e.row ?? 0) + 2}: ${e.message}`);
        const parsed: Row[] = [];
        res.data.forEach((raw, i) => {
          const row: Row = { code: "", name: "", description: "", brand: "", category: "", imageUrl: "" };
          for (const [h, value] of Object.entries(raw)) {
            const key = HEADERS[h];
            if (key) row[key] = (value ?? "").trim();
          }
          if (!row.code || !row.name) problems.push(`Linha ${i + 2}: código e nome são obrigatórios.`);
          else parsed.push(row);
        });
        setRows(parsed);
        setErrors(problems);
      },
    });
  };

  const run = async () => {
    setBusy(true);
    try {
      let created = 0;
      let updated = 0;
      for (let i = 0; i < rows.length; i += BATCH) {
        const r = await importRows({ rows: rows.slice(i, i + BATCH) });
        created += r.created;
        updated += r.updated;
      }
      toast.success(`${created} novas, ${updated} atualizadas`);
      setRows([]);
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Envie um arquivo CSV com as colunas: codigo, nome, descricao, marca, categoria e foto.
        Peças com código já existente são atualizadas.
      </p>
      <Button asChild variant="secondary">
        <label className="cursor-pointer">
          <FileSpreadsheetIcon /> Escolher arquivo CSV
          <input type="file" accept=".csv,text/csv" className="hidden" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
        </label>
      </Button>
      {errors.length > 0 && (
        <details className="rounded-lg border border-destructive/40 p-3 text-sm">
          <summary className="cursor-pointer font-semibold text-destructive">{errors.length} linha(s) com problema</summary>
          <ul className="mt-2 list-disc pl-5">
            {errors.slice(0, 50).map((e) => <li key={e}>{e}</li>)}
          </ul>
        </details>
      )}
      {rows.length > 0 && (
        <div className="flex items-center gap-3">
          <span className="text-sm">{rows.length} peças prontas para importar.</span>
          <Button onClick={run} disabled={busy}>{busy && <Spinner />} Importar</Button>
        </div>
      )}
    </div>
  );
}
