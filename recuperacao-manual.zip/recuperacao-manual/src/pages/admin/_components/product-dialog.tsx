import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { UploadIcon } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import ProductImage from "@/components/product-image.tsx";
import { errorMessage } from "../_lib/errors.ts";

type Props = {
  product: Doc<"products"> | "new" | null;
  categories: string[];
  onClose: () => void;
};

const EMPTY = { code: "", name: "", description: "", brand: "", category: "", imageUrl: "" };

// Remounted per product (via key) so the form always starts from the right values
function ProductForm({ product, categories, onClose }: Props) {
  const initial = product && product !== "new" ? product : null;
  const [form, setForm] = useState(
    initial
      ? {
          code: initial.code,
          name: initial.name,
          description: initial.description,
          brand: initial.brand,
          category: initial.category,
          imageUrl: initial.imageUrl,
        }
      : EMPTY,
  );
  const [busy, setBusy] = useState(false);
  const save = useMutation(api.admin.saveProduct);
  const getUploadUrl = useMutation(api.admin.generateUploadUrl);
  const getUrl = useMutation(api.admin.getStorageUrl);

  const set = (key: keyof typeof EMPTY, value: string) =>
    setForm((f) => ({ ...f, [key]: value }));

  const upload = async (file: File) => {
    setBusy(true);
    try {
      const url = await getUploadUrl({});
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      const { storageId } = (await res.json()) as { storageId: string };
      const publicUrl = await getUrl({ storageId: storageId as never });
      if (publicUrl) set("imageUrl", publicUrl);
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const submit = async () => {
    setBusy(true);
    try {
      await save({ id: initial?._id, ...form });
      toast.success("Peça salva");
      onClose();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <DialogContent className="max-h-[90vh] overflow-y-auto">
      <DialogHeader><DialogTitle>{initial ? "Editar peça" : "Nova peça"}</DialogTitle></DialogHeader>
      <div className="grid gap-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1"><Label>Código</Label><Input value={form.code} onChange={(e) => set("code", e.target.value)} /></div>
          <div className="space-y-1"><Label>Marca</Label><Input value={form.brand} onChange={(e) => set("brand", e.target.value)} /></div>
        </div>
        <div className="space-y-1"><Label>Nome</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></div>
        <div className="space-y-1">
          <Label>Categoria</Label>
          <Input list="categorias" value={form.category} onChange={(e) => set("category", e.target.value)} />
          <datalist id="categorias">{categories.map((c) => <option key={c} value={c} />)}</datalist>
        </div>
        <div className="space-y-1"><Label>Descrição</Label><Textarea value={form.description} onChange={(e) => set("description", e.target.value)} /></div>
        <div className="flex items-center gap-3">
          <ProductImage src={form.imageUrl} alt="Foto" className="size-20 shrink-0 rounded border" />
          <div className="flex-1 space-y-2">
            <Input value={form.imageUrl} onChange={(e) => set("imageUrl", e.target.value)} placeholder="Endereço da foto" />
            <Button asChild variant="secondary" size="sm">
              <label className="cursor-pointer">
                <UploadIcon /> Enviar foto
                <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
              </label>
            </Button>
          </div>
        </div>
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={busy}>{busy && <Spinner />} Salvar</Button>
      </DialogFooter>
    </DialogContent>
  );
}

export default function ProductDialog(props: Props) {
  const key = props.product === "new" ? "new" : (props.product?._id ?? "none");
  return (
    <Dialog open={props.product !== null} onOpenChange={(o) => !o && props.onClose()}>
      {props.product !== null && <ProductForm key={key} {...props} />}
    </Dialog>
  );
}
