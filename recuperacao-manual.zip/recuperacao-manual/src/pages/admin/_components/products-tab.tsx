import { useState } from "react";
import { useMutation, usePaginatedQuery, useQuery } from "convex/react";
import { toast } from "sonner";
import { PencilIcon, PlusIcon, Trash2Icon } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import ProductImage from "@/components/product-image.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import ProductDialog from "./product-dialog.tsx";
import { errorMessage } from "../_lib/errors.ts";

export default function ProductsTab() {
  const [search, setSearch] = useState("");
  const [debounced] = useDebounce(search, 300);
  const [editing, setEditing] = useState<Doc<"products"> | "new" | null>(null);
  const remove = useMutation(api.admin.deleteProduct);
  const categories = useQuery(api.catalog.listCategories, {});
  const { results, status, loadMore } = usePaginatedQuery(
    api.catalog.listProducts,
    { search: debounced.trim() || undefined },
    { initialNumItems: 20 },
  );

  const onDelete = async (p: Doc<"products">) => {
    if (!window.confirm(`Excluir "${p.name}"?`)) return;
    try {
      await remove({ id: p._id });
      toast.success("Peça excluída");
    } catch (e) {
      toast.error(errorMessage(e));
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por nome ou código" />
        <Button onClick={() => setEditing("new")}><PlusIcon /> Nova peça</Button>
      </div>
      {status === "LoadingFirstPage" ? (
        <Skeleton className="h-64 w-full" />
      ) : (
        <ul className="divide-y rounded-lg border bg-card">
          {results.map((p) => (
            <li key={p._id} className="flex items-center gap-3 p-3">
              <ProductImage src={p.imageUrl} alt={p.name} className="size-12 shrink-0 rounded" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{p.name}</p>
                <p className="truncate text-xs text-muted-foreground">
                  <span className="font-mono text-primary">{p.code}</span> · {p.brand} · {p.category}
                </p>
              </div>
              <Button size="icon" variant="ghost" onClick={() => setEditing(p)} aria-label="Editar"><PencilIcon /></Button>
              <Button size="icon" variant="ghost" onClick={() => onDelete(p)} aria-label="Excluir"><Trash2Icon /></Button>
            </li>
          ))}
        </ul>
      )}
      {status === "CanLoadMore" && (
        <Button variant="secondary" onClick={() => loadMore(20)}>Ver mais</Button>
      )}
      <ProductDialog
        product={editing}
        categories={(categories ?? []).map((c) => c.name)}
        onClose={() => setEditing(null)}
      />
    </div>
  );
}
