import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { errorMessage } from "../_lib/errors.ts";

type Values = { whatsappNumber: string; quoteEmail: string };

function SettingsForm({ initial }: { initial: Values }) {
  const [form, setForm] = useState(initial);
  const save = useMutation(api.settings.save);

  const submit = async () => {
    try { await save(form); toast.success("Configurações salvas"); }
    catch (e) { toast.error(errorMessage(e)); }
  };

  return (
    <div className="max-w-lg space-y-5">
      <div className="space-y-1">
        <Label>WhatsApp da SGLASS (com DDD)</Label>
        <Input value={form.whatsappNumber} onChange={(e) => setForm({ ...form, whatsappNumber: e.target.value })} placeholder="(11) 91234-5678" />
        <p className="text-xs text-muted-foreground">Os pedidos de orçamento chegam neste número. Deixe vazio para esconder o botão.</p>
      </div>
      <div className="space-y-1">
        <Label>E-mail que recebe os orçamentos</Label>
        <Input type="email" value={form.quoteEmail} onChange={(e) => setForm({ ...form, quoteEmail: e.target.value })} placeholder="vendas@suaempresa.com.br" />
        <p className="text-xs text-muted-foreground">O cliente abre o próprio aplicativo de e-mail com o pedido pronto. Deixe vazio para esconder o botão.</p>
      </div>
      <Button onClick={submit}>Salvar</Button>
    </div>
  );
}

export default function SettingsTab() {
  const settings = useQuery(api.settings.getForAdmin, {});
  if (settings === undefined) return <Skeleton className="h-64 w-full" />;
  return <SettingsForm initial={settings} />;
}
