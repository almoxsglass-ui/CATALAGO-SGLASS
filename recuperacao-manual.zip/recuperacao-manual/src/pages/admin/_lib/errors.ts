import { ConvexError } from "convex/values";

export function errorMessage(e: unknown): string {
  if (e instanceof ConvexError) {
    const data = e.data as { message?: string };
    return data.message ?? "Algo deu errado.";
  }
  return "Algo deu errado. Tente novamente.";
}
