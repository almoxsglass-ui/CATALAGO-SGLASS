import { useQuery, Authenticated, Unauthenticated, AuthLoading } from "convex/react";
import { ShieldAlertIcon } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import SiteHeader from "@/components/site-header.tsx";
import SiteFooter from "@/components/site-footer.tsx";
import { SignInButton } from "@/components/ui/signin.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import ProductsTab from "./_components/products-tab.tsx";
import CategoriesTab from "./_components/categories-tab.tsx";
import ImportTab from "./_components/import-tab.tsx";
import DiagramsTab from "./_components/diagrams-tab.tsx";
import SettingsTab from "./_components/settings-tab.tsx";

function AdminContent() {
  const isAdmin = useQuery(api.admin.isAdmin, {});

  if (isAdmin === undefined) return <Skeleton className="h-64 w-full" />;
  if (!isAdmin) {
    return (
      <Empty>
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <ShieldAlertIcon />
          </EmptyMedia>
          <EmptyTitle>Acesso restrito</EmptyTitle>
          <EmptyDescription>Esta conta não é de administrador.</EmptyDescription>
        </EmptyHeader>
        <SignInButton variant="secondary" />
      </Empty>
    );
  }
  return (
    <Tabs defaultValue="products">
      <TabsList>
        <TabsTrigger value="products">Peças</TabsTrigger>
        <TabsTrigger value="categories">Categorias</TabsTrigger>
        <TabsTrigger value="import">Importar planilha</TabsTrigger>
        <TabsTrigger value="diagrams">Vistas explodidas</TabsTrigger>
        <TabsTrigger value="settings">Contatos</TabsTrigger>
      </TabsList>
      <TabsContent value="diagrams" className="pt-4"><DiagramsTab /></TabsContent>
      <TabsContent value="settings" className="pt-4"><SettingsTab /></TabsContent>
      <TabsContent value="products" className="pt-4"><ProductsTab /></TabsContent>
      <TabsContent value="categories" className="pt-4"><CategoriesTab /></TabsContent>
      <TabsContent value="import" className="pt-4"><ImportTab /></TabsContent>
    </Tabs>
  );
}

export default function AdminPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-4xl flex-1 space-y-6 px-4 py-8">
        <h1 className="text-3xl font-bold tracking-tight">Administração</h1>
        <AuthLoading><Skeleton className="h-64 w-full" /></AuthLoading>
        <Unauthenticated>
          <div className="space-y-3">
            <p className="text-muted-foreground">Entre para gerenciar o catálogo.</p>
            <SignInButton />
          </div>
        </Unauthenticated>
        <Authenticated><AdminContent /></Authenticated>
      </main>
      <SiteFooter />
    </div>
  );
}
