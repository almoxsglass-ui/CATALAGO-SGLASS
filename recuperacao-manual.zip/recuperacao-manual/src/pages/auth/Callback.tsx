import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/use-auth.ts";
import { useConvexAuth, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Button } from "@/components/ui/button.tsx";
import { authCallbackMessages, type AuthCallbackMessages } from "./callback-messages.ts";

interface AuthCallbackProps { messages?: AuthCallbackMessages }

export default function AuthCallback({ messages: {
  loading = authCallbackMessages.en.loading,
  errorTitle = authCallbackMessages.en.errorTitle,
  missingState = authCallbackMessages.en.missingState,
  returnHome = authCallbackMessages.en.returnHome,
  tryAgain = authCallbackMessages.en.tryAgain,
} = {} }: AuthCallbackProps): React.JSX.Element {
  const navigate = useNavigate();
  const auth = useAuth();
  const convexAuth = useConvexAuth();
  const updateCurrentUser = useMutation(api.users.updateCurrentUser);
  const [error, setError] = useState<string | null>(null);
  const syncing = useRef(false);
  const navigateHome = useCallback(() => navigate("/", { replace: true }), [navigate]);

  useEffect(() => {
    if (auth.error) { setError(auth.error.message); return; }
    if (auth.isLoading || convexAuth.isLoading || !auth.isAuthenticated) return;
    if (!convexAuth.isAuthenticated) {
      setError("O provedor OIDC não foi aceito pelo backend Convex. Confira o emissor e o audience configurados.");
      return;
    }
    if (syncing.current) return;
    syncing.current = true;
    updateCurrentUser().then(navigateHome).catch((e: unknown) => {
      setError(e instanceof Error ? e.message : String(e));
      syncing.current = false;
    });
  }, [auth.error, auth.isLoading, auth.isAuthenticated, convexAuth.isLoading, convexAuth.isAuthenticated, updateCurrentUser, navigateHome]);

  if (error) return (
    <div className="flex h-svh flex-col items-center justify-center gap-6 px-4">
      <div className="flex flex-col items-center gap-2 text-center">
        <p className="font-medium text-destructive">{errorTitle}</p>
        <p className="max-w-md text-sm text-muted-foreground">
          {error === "No matching state found in storage" ? missingState : error}
        </p>
      </div>
      <div className="flex gap-3">
        <Button variant="secondary" onClick={navigateHome}>{returnHome}</Button>
        <Button onClick={() => { setError(null); void auth.signin(); }}>{tryAgain}</Button>
      </div>
    </div>
  );

  return (
    <div className="flex h-svh flex-col items-center justify-center gap-4">
      <Spinner className="size-8" aria-label={loading} />
      <p className="text-sm text-muted-foreground">{loading}</p>
    </div>
  );
}
