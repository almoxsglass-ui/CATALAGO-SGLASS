import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import SiteHeader from "@/components/site-header.tsx";
import SiteFooter from "@/components/site-footer.tsx";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import PartDialog from "./part-dialog.tsx";
import { cn } from "@/lib/utils.ts";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";

type Hotspot = Doc<"diagrams">["hotspots"][number];

type PartRowProps = {
  spot: Hotspot;
  active: boolean;
  onHover: (n: number | null) => void;
  onOpen: (spot: Hotspot) => void;
};

function PartRow({ spot, active, onHover, onOpen }: PartRowProps) {
  return (
    <li>
      <button
        type="button"
        onClick={() => onOpen(spot)}
        onMouseEnter={() => onHover(spot.n)}
        onMouseLeave={() => onHover(null)}
        className={cn(
          "flex w-full cursor-pointer items-center gap-3 rounded-lg border bg-card p-3 text-left transition hover:border-primary",
          active && "border-primary bg-accent",
        )}
      >
        <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
          {spot.n}
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold leading-tight">{spot.pt}</p>
          <p className="truncate text-xs text-muted-foreground">{spot.en}</p>
          <p className="font-mono text-xs text-primary">{spot.code}</p>
        </div>
      </button>
    </li>
  );
}

export default function DiagramsPage() {
  const diagrams = useQuery(api.diagrams.list, {});
  const [slug, setSlug] = useState<string | null>(null);
  const [hover, setHover] = useState<number | null>(null);
  const [open, setOpen] = useState<Hotspot | null>(null);
  const diagram = diagrams?.find((d) => d.slug === slug) ?? diagrams?.[0];

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-7xl flex-1 space-y-6 px-4 py-8">
        <section className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Vistas explodidas</h1>
          <p className="text-muted-foreground">
            Toque em um número do desenho ou da lista para ver a peça.
          </p>
        </section>
        {diagrams === undefined && <Skeleton className="h-96 w-full" />}
        {diagrams?.length === 0 && (
          <p className="text-muted-foreground">Nenhuma vista explodida cadastrada.</p>
        )}
        {diagram && diagrams && (
        <>
        <Tabs value={diagram.slug} onValueChange={setSlug}>
          <TabsList>
            {diagrams.map((d) => (
              <TabsTrigger key={d.slug} value={d.slug}>
                {d.title}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
        <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
          <div className="self-start overflow-hidden rounded-lg border bg-white">
            <div className="relative">
            <img src={diagram.imageUrl} alt={diagram.title} className="block w-full" />
            {diagram.hotspots.map((s) => (
              <button
                key={s.n}
                aria-label={s.pt}
                onMouseEnter={() => setHover(s.n)}
                onMouseLeave={() => setHover(null)}
                onClick={() => setOpen(s)}
                style={{ left: `${s.x}%`, top: `${s.y}%` }}
                className={cn(
                  "absolute flex size-7 -translate-x-1/2 -translate-y-1/2 cursor-pointer items-center justify-center rounded-full border-2 border-white bg-primary text-xs font-bold text-primary-foreground shadow transition hover:scale-110",
                  hover === s.n && "scale-125 ring-4 ring-primary/40",
                )}
              >
                {s.n}
              </button>
            ))}
            </div>
          </div>
          <ul className="space-y-2">
            {diagram.hotspots.map((s) => (
              <PartRow key={s.n} spot={s} active={hover === s.n} onHover={setHover} onOpen={setOpen} />
            ))}
          </ul>
        </div>
        </>
        )}
      </main>
      <PartDialog spot={open} onClose={() => setOpen(null)} />
      <SiteFooter />
    </div>
  );
}
