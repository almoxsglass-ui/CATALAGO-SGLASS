import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { toast } from "sonner";
import { PlusIcon } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import ProductImage from "@/components/product-image.tsx";
import { addItem } from "@/lib/selection.ts";

export type Spot = { n: number; pt: string; en: string; code: string };

function PartDetails({ spot, onClose }: { spot: Spot; onClose: () => void }) {
  const product = useQuery(api.catalog.getProductByCode, { code: spot.code });

  if (product === undefined) return <Skeleton className="h-64 w-full" />;
  if (product === null) {
    return (
      <p className="text-sm text-muted-foreground">
        Esta peça (código {spot.code}) ainda não está no catálogo.
      </p>
    );
  }

  const add = () => {
    addItem({
      id: product._id,
      code: product.code,
      name: product.name,
      brand: product.brand,
      imageUrl: product.imageUrl,
    });
    toast.success("Adicionado ao orçamento");
    onClose();
  };

  return (
    <div className="space-y-4">
      <ProductImage src={product.imageUrl} alt={product.name} className="h-56 w-full rounded-lg" />
      <div className="space-y-1">
        <p className="font-semibold">{product.name}</p>
        <p className="font-mono text-sm text-primary">{product.code}</p>
        <p className="text-sm text-muted-foreground">{product.brand}</p>
        {product.description && <p className="text-sm">{product.description}</p>}
      </div>
      <div className="flex gap-2">
        <Button className="flex-1" onClick={add}>
          <PlusIcon /> Adicionar ao orçamento
        </Button>
        <Button asChild variant="secondary">
          <Link to={`/produto/${product._id}`}>Ver página</Link>
        </Button>
      </div>
    </div>
  );
}

export default function PartDialog({ spot, onClose }: { spot: Spot | null; onClose: () => void }) {
  return (
    <Dialog open={spot !== null} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        {spot && (
          <>
            <DialogHeader>
              <DialogTitle>
                {spot.n}. {spot.pt}
              </DialogTitle>
              <DialogDescription>{spot.en}</DialogDescription>
            </DialogHeader>
            <PartDetails spot={spot} onClose={onClose} />
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
