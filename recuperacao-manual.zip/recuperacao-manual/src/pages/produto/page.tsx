import { Link, useParams } from "react-router-dom";
import { useQuery } from "convex/react";
import { ArrowLeftIcon, PackageXIcon, PlusIcon } from "lucide-react";
import { toast } from "sonner";
import { addItem } from "@/lib/selection.ts";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import SiteHeader from "@/components/site-header.tsx";
import SiteFooter from "@/components/site-footer.tsx";
import ProductImage from "@/components/product-image.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";

type SpecProps = { label: string; value: string };

function Spec({ label, value }: SpecProps) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b py-3 last:border-b-0">
      <dt className="text-sm text-muted-foreground">{label}</dt>
      <dd className="text-right text-sm font-semibold">{value}</dd>
    </div>
  );
}

export default function ProductPage() {
  const { id } = useParams();
  // An invalid id throws on the backend, so guard it before querying
  const product = useQuery(
    api.catalog.getProduct,
    id ? { id: id as Id<"products"> } : "skip",
  );

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-5xl flex-1 space-y-6 px-4 py-8">
        <Button asChild variant="ghost" size="sm">
          <Link to="/">
            <ArrowLeftIcon /> Voltar ao catálogo
          </Link>
        </Button>

        {product === undefined ? (
          <div className="grid gap-8 md:grid-cols-2">
            <Skeleton className="aspect-square w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        ) : product === null ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <PackageXIcon />
              </EmptyMedia>
              <EmptyTitle>Peça não encontrada</EmptyTitle>
              <EmptyDescription>
                Ela pode ter sido removida do catálogo.
              </EmptyDescription>
            </EmptyHeader>
            <EmptyContent>
              <Button asChild size="sm">
                <Link to="/">Ver catálogo</Link>
              </Button>
            </EmptyContent>
          </Empty>
        ) : (
          <div className="grid gap-8 md:grid-cols-2">
            <ProductImage
              src={product.imageUrl}
              alt={product.name}
              className="aspect-square w-full rounded-lg border p-6"
            />
            <div className="space-y-5">
              <div className="space-y-2">
                <p className="font-mono text-sm font-semibold text-primary">
                  {product.code}
                </p>
                <h1 className="text-balance text-2xl font-bold leading-tight">
                  {product.name}
                </h1>
                {product.description && (
                  <p className="text-muted-foreground">{product.description}</p>
                )}
              </div>
              <Button
                size="lg"
                onClick={() => {
                  addItem({
                    id: product._id,
                    code: product.code,
                    name: product.name,
                    brand: product.brand,
                    imageUrl: product.imageUrl,
                  });
                  toast.success("Adicionado ao orçamento");
                }}
              >
                <PlusIcon /> Adicionar ao orçamento
              </Button>
              <dl className="rounded-lg border bg-card px-4">
                <Spec label="Código" value={product.code} />
                <Spec label="Marca" value={product.brand} />
                <Spec label="Categoria" value={product.category} />
              </dl>
            </div>
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
